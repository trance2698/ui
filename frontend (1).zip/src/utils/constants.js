const api_url = `http://localhost:8000`
const planner_Id = `localStorage.getItem("plannerId")`
export const apiUrl = api_url
export const plannerId = planner_Id
